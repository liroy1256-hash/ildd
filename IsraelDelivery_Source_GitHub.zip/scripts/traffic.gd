class_name Traffic
extends Node3D
## תנועה עירונית: רכבים על גרף הכבישים (נתיב ימני, רמזורים, שמירת מרחק, יוצאים מהדרך של השחקן)
## ורכבת על גשר המסילה. מאגר רכבים קבוע (pooling), צפיפות לפי הגדרה ושעה.

const POOL := 40
const LANE := 3.4

var world: World
var player: Node3D
var cars: Array = []
var density := 24
var _train: Node3D
var _train_z := -100.0
var _train_dir := 1.0
var _train_wait := 0.0
var _stopped_here := false


func setup(w: World, p: Node3D) -> void:
    world = w
    player = p
    if cars.is_empty():
        for i in range(POOL):
            cars.append(_make_car(i))
        _make_train()
    for c in cars:
        _respawn(c)


func set_density_level(level: int) -> void:
    density = [0, 12, 24, 40][clampi(level, 0, 3)]


func _mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.6
    return m


func _mesh_box(parent: Node3D, size: Vector3, pos: Vector3, col: Color) -> void:
    var mi := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    mi.mesh = b
    mi.material_override = _mat(col)
    mi.position = pos
    parent.add_child(mi)


func _make_car(i: int) -> Dictionary:
    var rng := RandomNumberGenerator.new()
    rng.seed = 1000 + i
    var col: Color = World.CAR_COLS[rng.randi() % World.CAR_COLS.size()]
    var kind := "car"
    var r := rng.randf()
    if r > 0.88:
        kind = "bus"
    elif r > 0.7:
        kind = "van"
    var body := AnimatableBody3D.new()
    var size := Vector3(1.9, 1.4, 4.3)
    if kind == "bus":
        size = Vector3(2.6, 3.2, 11.0)
        col = Color("1d6fd1")
        _mesh_box(body, Vector3(2.6, 2.2, 11.0), Vector3(0, 1.7, 0), col)
        _mesh_box(body, Vector3(2.64, 0.9, 9.6), Vector3(0, 2.2, 0), Color("22303c"))
    elif kind == "van":
        size = Vector3(2.0, 2.2, 5.2)
        _mesh_box(body, Vector3(2.0, 1.8, 5.2), Vector3(0, 1.3, 0), col)
        _mesh_box(body, Vector3(2.02, 0.7, 1.4), Vector3(0, 1.8, -1.9), Color("22303c"))
    else:
        _mesh_box(body, Vector3(1.9, 0.7, 4.3), Vector3(0, 0.55, 0), col)
        _mesh_box(body, Vector3(1.7, 0.6, 2.3), Vector3(0, 1.15, 0.2), col.darkened(0.15))
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    cs.position = Vector3(0, size.y * 0.5, 0)
    body.add_child(cs)
    add_child(body)
    return {"node": body, "shape": cs, "from": Vector2i(0, 0), "to": Vector2i(1, 0), "t": 0.0, "speed": 0.0,
        "vmax": rng.randf_range(8.0, 12.0) if kind != "bus" else 8.0, "len": size.z, "pos": Vector3.ZERO, "yaw": 0.0, "on": false, "idx": i}


func _make_train() -> void:
    _train = Node3D.new()
    for k in range(4):
        _mesh_box(_train, Vector3(3.0, 3.4, 15.0), Vector3(0, 0, k * 16.0 - 24.0), Color("e8eaec"))
        _mesh_box(_train, Vector3(3.04, 0.9, 13.0), Vector3(0, 0.5, k * 16.0 - 24.0), Color("22303c"))
        _mesh_box(_train, Vector3(3.06, 0.35, 15.0), Vector3(0, -1.0, k * 16.0 - 24.0), Color("1d6fd1"))
    add_child(_train)


func _node_pos(n: Vector2i) -> Vector3:
    return Vector3(n.x * World.S, 0.0, n.y * World.S)


func _respawn(c: Dictionary) -> void:
    var around := Vector3(World.SIZE * 0.5, 0, World.SIZE * 0.5)
    if player != null:
        around = player.global_position
    var ni := clampi(roundi(around.x / World.S) + randi_range(-4, 4), 0, World.N)
    var nj := clampi(roundi(around.z / World.S) + randi_range(-4, 4), 0, World.N)
    var nb: Array = world.out_neighbors(ni, nj)
    if nb.is_empty():
        return
    c.from = Vector2i(ni, nj)
    c.to = nb[randi() % nb.size()]
    c.t = randf_range(0.0, World.S * 0.8)
    c.speed = 0.0
    _place(c, 1.0, true)


func _place(c: Dictionary, delta: float, snap: bool) -> void:
    var a := _node_pos(c.from)
    var b := _node_pos(c.to)
    var d := (b - a).normalized()
    var right := Vector3(-d.z, 0, d.x)
    var target: Vector3 = a + d * float(c.t) + right * LANE
    var yaw := atan2(-d.x, -d.z)
    if snap:
        c.pos = target
        c.yaw = yaw
    else:
        c.pos = (c.pos as Vector3).lerp(target, minf(1.0, 8.0 * delta))
        c.yaw = lerp_angle(float(c.yaw), yaw, minf(1.0, 8.0 * delta))
    var n: Node3D = c.node
    n.global_position = c.pos
    n.rotation.y = c.yaw


func _factor(hour: float) -> float:
    if hour >= 22.0 or hour < 5.0:
        return 0.25
    if (hour >= 7.0 and hour < 9.5) or (hour >= 16.0 and hour < 19.0):
        return 1.0
    return 0.7


func _physics_process(delta: float) -> void:
    if world == null or player == null:
        return
    var active := int(density * _factor(Game.hour_f()))
    var by_edge := {}
    for c in cars:
        var on: bool = int(c.idx) < active
        if on != c.on:
            c.on = on
            (c.node as Node3D).visible = on
            (c.shape as CollisionShape3D).disabled = not on
            if on:
                _respawn(c)
        if on:
            var key := "%d_%d_%d_%d" % [c.from.x, c.from.y, c.to.x, c.to.y]
            if not by_edge.has(key):
                by_edge[key] = []
            by_edge[key].append(c)
    var ppos := player.global_position
    for c in cars:
        if not c.on:
            continue
        if (c.pos as Vector3).distance_to(ppos) > 420.0:
            _respawn(c)
            continue
        var a := _node_pos(c.from)
        var b := _node_pos(c.to)
        var d := (b - a).normalized()
        var remaining: float = World.S - float(c.t)
        var v := float(c.vmax)
        if remaining < 14.0 and remaining > 3.5:
            var axis := "ew" if absf(d.x) > 0.5 else "ns"
            if world.signal_state(axis) != "g":
                v = 0.0
        var key2 := "%d_%d_%d_%d" % [c.from.x, c.from.y, c.to.x, c.to.y]
        for o in by_edge.get(key2, []):
            if o != c and float(o.t) > float(c.t):
                var gap: float = float(o.t) - float(c.t) - (float(c.len) + float(o.len)) * 0.5
                if gap < 14.0:
                    v = minf(v, maxf(0.0, (gap - 2.0) * 1.3))
        var to_p := ppos - (c.pos as Vector3)
        to_p.y = 0.0
        if to_p.length() < 14.0 and to_p.normalized().dot(d) > 0.8:
            var lat := absf(to_p.dot(Vector3(-d.z, 0, d.x)) - LANE)
            if lat < 2.6:
                v = minf(v, maxf(0.0, (to_p.length() - 5.0) * 0.8))
        c.speed = move_toward(float(c.speed), v, (3.0 if v > float(c.speed) else 9.0) * delta)
        c.t = float(c.t) + float(c.speed) * delta
        if float(c.t) >= World.S:
            var prev: Vector2i = c.from
            var here: Vector2i = c.to
            var opts: Array = world.out_neighbors(here.x, here.y)
            var fwd: Array = opts.filter(func(n): return n != prev)
            if fwd.is_empty():
                fwd = opts
            if fwd.is_empty():
                _respawn(c)
                continue
            c.from = here
            c.to = fwd[randi() % fwd.size()]
            c.t = float(c.t) - World.S
        _place(c, delta, false)
    _update_train(delta)


func _update_train(delta: float) -> void:
    if _train == null:
        return
    var stop_z := World.STATION_ROW * World.S + World.S * 0.5
    var dist := (stop_z - _train_z) * _train_dir
    if _train_wait > 0.0:
        _train_wait -= delta
    else:
        var v := 16.0
        if dist > 0.0 and dist < 70.0:
            v = clampf(dist * 0.35 + 1.5, 1.5, 16.0)
        _train_z += _train_dir * v * delta
        if dist <= 0.4 and dist > -3.0 and not _stopped_here:
            _train_wait = 6.0
            _stopped_here = true
        elif dist < -10.0:
            _stopped_here = false
        if _train_z > World.SIZE + 150.0:
            _train_dir = -1.0
            _stopped_here = false
        elif _train_z < -150.0:
            _train_dir = 1.0
            _stopped_here = false
    _train.position = Vector3(World.RAIL_COL * World.S + World.S * 0.5 + 0.0, 7.9, _train_z)
    _train.rotation.y = 0.0 if _train_dir > 0.0 else PI
