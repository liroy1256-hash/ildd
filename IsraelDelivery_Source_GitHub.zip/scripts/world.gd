class_name World
extends Node3D
## עולם סכמטי בהשראת תל אביב. מבנים מגוונים, ונדליזם מינימלי, תאורת לילה, רמזורים, רכבת על גשר,
## וטעינה הדרגתית של אריחים. פרטים קטנים מצוירים ב-MultiMesh לצורך ביצועים.

const N := 24
const S := 64.0
const R := 14.0
const SET := 4.0
const CHUNK := 2
const SIZE := 1536.0
const RAIL_COL := 17
const STATION_ROW := 12

const V_NAMES := {0: "טיילת הרברט סמואל", 3: "רחוב בן יהודה", 7: "רחוב דיזנגוף", 12: "רחוב אבן גבירול", 22: "נתיבי איילון"}
const H_NAMES := {4: "רחוב ארלוזורוב", 8: "רחוב פרישמן", 12: "שדרות רוטשילד", 16: "רחוב אלנבי", 20: "רחוב ז'בוטינסקי"}
const ONEWAY_V := {5: 1}
const ONEWAY_H := {10: 1}
const LAND := {
    Vector2i(20, 5): ["מגדלי עזריאלי", "azrieli"],
    Vector2i(20, 6): ["קניון עזריאלי", "mall"],
    Vector2i(13, 3): ["קניון TLV", "mall"],
    Vector2i(3, 16): ["שוק הכרמל", "market"],
    Vector2i(0, 11): ["חוף תל אביב", "beach"],
    Vector2i(9, 13): ["שדרות רוטשילד", "plaza"],
    Vector2i(21, 12): ["נתיבי איילון", "ayalon"],
}
const R_NAMES := ["פלאפל הפינה", "שווארמה הכיכר", "פיצה הים", "המבורגר העיר", "קפה הבוקר", "מאפיית הלחם", "סושי הנמל", "חומוס השכונה", "פיצה שמש", "בורקס הדר", "קפה לב העיר", "סלט וקפה"]
const B_NAMES := ["בנק העיר", "בנק הים", "בנק המרכז"]
const M_NAMES := ["סופר השכונה", "מכולת הפינה", "סופר העיר", "מינימרקט שמש", "סופר הדר"]
const PARK_NAMES := ["גן העיר", "פארק השכונה", "גן הרצל", "פארק הים"]
const WATER_NAMES := ["פארק המים", "פארק מים שמש"]
const SCHOOL_NAMES := ["בית ספר אלון", "בית ספר גבעה", "בית ספר שחר", "בית ספר רמון"]
const GAS_NAMES := ["תחנת דלק הדרך", "תחנת דלק הצומת", "תחנת דלק הים"]
const CLINIC_NAMES := ["מרפאת העיר", "מרפאת הצפון", "מרפאה שכונתית"]
const OFFICE_NAMES := ["מגדל הים", "מגדל העסקים", "מגדל המרכז", "מגדל הנמל"]
const SHOP_LABELS := ["קפה", "פיצה", "פרחים", "מאפייה", "בית מרקחת", "מכולת", "חומוס", "ספרים"]
const PALETTE := [Color("efe9dd"), Color("e6e0d2"), Color("f4f1ea"), Color("dcd6c8"), Color("e9e4d6"), Color("d7dde0"), Color("cfd3d6"), Color("e7d9c4")]
const OLD_PALETTE := [Color("d9cdb4"), Color("cfc2a6"), Color("e0d6c0"), Color("c9b99a")]
const GLASS := [Color("6f8ea3"), Color("5d7b8f"), Color("7f9bb0")]
const SIGN_COLS := [Color("c0392b"), Color("e67e22"), Color("27ae60"), Color("8e44ad"), Color("2980b9"), Color("d35400")]
const CAR_COLS := [Color("c0392b"), Color("2c3e50"), Color("ecf0f1"), Color("7f8c8d"), Color("f1c40f"), Color("27ae60"), Color("2980b9")]

var load_r := 2
var chunks := {}
var astar := AStar2D.new()
var night := 0.0
var _queue: Array = []
var _poi_cache := {}
var _mats := {}
var _meshes := {}
var _fac_mats := {}
var _tex_a: ImageTexture
var _tex_e: ImageTexture
var _vc_mat: StandardMaterial3D
var _lamp_mat: StandardMaterial3D
var _glow_mat: StandardMaterial3D
var _sig_ns: StandardMaterial3D
var _sig_ew: StandardMaterial3D
var _sig_t := 0.0
var _sig_last := ""


func _ready() -> void:
    for j in range(N + 1):
        for i in range(N + 1):
            astar.add_point(_nid(i, j), Vector2(i * S, j * S))
    for j in range(N + 1):
        for i in range(N + 1):
            if i < N:
                _link(_nid(i, j), _nid(i + 1, j), int(ONEWAY_H.get(j, 0)))
            if j < N:
                _link(_nid(i, j), _nid(i, j + 1), int(ONEWAY_V.get(i, 0)))
    _init_materials()
    _build_ground()


func _nid(i: int, j: int) -> int:
    return j * (N + 1) + i


func _link(a: int, b: int, dir: int) -> void:
    if dir == 0:
        astar.connect_points(a, b, true)
    elif dir > 0:
        astar.connect_points(a, b, false)
    else:
        astar.connect_points(b, a, false)


func _h(i: int, j: int) -> int:
    return absi(((i + 7) * 73856093) ^ ((j + 13) * 19349663))


func out_neighbors(i: int, j: int) -> Array:
    var out: Array = []
    var dh := int(ONEWAY_H.get(j, 0))
    var dv := int(ONEWAY_V.get(i, 0))
    if i < N and dh >= 0:
        out.append(Vector2i(i + 1, j))
    if i > 0 and dh <= 0:
        out.append(Vector2i(i - 1, j))
    if j < N and dv >= 0:
        out.append(Vector2i(i, j + 1))
    if j > 0 and dv <= 0:
        out.append(Vector2i(i, j - 1))
    return out


# ---------- חומרים ותאורת לילה ----------
func _init_materials() -> void:
    var ia := Image.create(128, 160, false, Image.FORMAT_RGBA8)
    ia.fill(Color.WHITE)
    var ie := Image.create(128, 160, false, Image.FORMAT_RGBA8)
    ie.fill(Color.BLACK)
    var rng := RandomNumberGenerator.new()
    rng.seed = 77
    for cy in range(4):
        for cx in range(4):
            var r := Rect2i(cx * 32 + 7, cy * 32 + 8, 18, 16)
            ia.fill_rect(r, Color(0.2, 0.27, 0.33))
            if rng.randf() < 0.42:
                ie.fill_rect(r, Color(1.0, 0.78, 0.45))
        ia.fill_rect(Rect2i(0, cy * 32 + 29, 128, 3), Color(0.82, 0.82, 0.82))
    _tex_a = ImageTexture.create_from_image(ia)
    _tex_e = ImageTexture.create_from_image(ie)
    _vc_mat = StandardMaterial3D.new()
    _vc_mat.vertex_color_use_as_albedo = true
    _vc_mat.roughness = 0.9
    _lamp_mat = _emit_mat(Color("fff1c4"))
    _glow_mat = _emit_mat(Color("ffd9a0"))
    _sig_ns = _emit_mat(Color("e5252a"))
    _sig_ew = _emit_mat(Color("e5252a"))
    _sig_ns.emission_energy_multiplier = 2.0
    _sig_ew.emission_energy_multiplier = 2.0


func _emit_mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.emission_enabled = true
    m.emission = c
    m.emission_energy_multiplier = 0.0
    return m


func set_night(v: float) -> void:
    night = clampf(v, 0.0, 1.0)
    for k in _fac_mats:
        _fac_mats[k].emission_energy_multiplier = night * 1.8
    _lamp_mat.emission_energy_multiplier = night * 3.0
    _glow_mat.emission_energy_multiplier = 0.25 + night * 1.6


func _fac_mat(col: Color, nx: int, ny: int) -> StandardMaterial3D:
    var key := "%s_%d_%d" % [col.to_html(false), nx, ny]
    if _fac_mats.has(key):
        return _fac_mats[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = col
    m.albedo_texture = _tex_a
    m.uv1_scale = Vector3(nx / 4.0, ny / 5.0, 1.0)
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    m.roughness = 0.85
    m.emission_enabled = true
    m.emission_texture = _tex_e
    m.emission = Color.WHITE
    m.emission_energy_multiplier = night * 1.8
    _fac_mats[key] = m
    return m


func signal_state(axis: String) -> String:
    var t := fposmod(_sig_t, 40.0)
    if axis == "ns":
        return "g" if t < 16.0 else ("y" if t < 18.0 else "r")
    return "g" if (t >= 20.0 and t < 36.0) else ("y" if (t >= 36.0 and t < 38.0) else "r")


func _update_signals() -> void:
    var a := signal_state("ns")
    var b := signal_state("ew")
    if a + b == _sig_last:
        return
    _sig_last = a + b
    for pair in [[_sig_ns, a], [_sig_ew, b]]:
        var c := Color("e5252a")
        if pair[1] == "g":
            c = Color("22d45a")
        elif pair[1] == "y":
            c = Color("ffc400")
        pair[0].albedo_color = c
        pair[0].emission = c


# ---------- נתונים ----------
func poi(i_in, j_in) -> Dictionary:
    var i := int(i_in)
    var j := int(j_in)
    var key := Vector2i(i, j)
    if _poi_cache.has(key):
        return _poi_cache[key]
    var h := _h(i, j)
    var hh := floori(h / 100.0)
    var kind := "home"
    var nm := ""
    var sub := ""
    var addr := "%s %d" % [street_name_h(j + 1), 1 + floori(h / 7.0) % 60]
    if LAND.has(key):
        kind = "landmark"
        nm = LAND[key][0]
        sub = LAND[key][1]
    elif i == RAIL_COL:
        kind = "rail"
        sub = "station" if j == STATION_ROW else "viaduct"
        nm = "תחנת רכבת תל אביב" if j == STATION_ROW else addr
    else:
        var m := h % 100
        if m < 9:
            kind = "restaurant"
            nm = R_NAMES[hh % R_NAMES.size()]
        elif m < 11:
            kind = "bank"
            nm = B_NAMES[hh % B_NAMES.size()]
        elif m < 16:
            kind = "supermarket"
            nm = M_NAMES[hh % M_NAMES.size()]
        elif m < 18:
            kind = "venue"
            sub = "gas"
            nm = GAS_NAMES[hh % GAS_NAMES.size()]
        elif m < 25:
            kind = "venue"
            sub = "waterpark" if hh % 3 == 0 else "park"
            nm = WATER_NAMES[hh % WATER_NAMES.size()] if sub == "waterpark" else PARK_NAMES[hh % PARK_NAMES.size()]
        elif m < 27:
            kind = "venue"
            sub = "school"
            nm = SCHOOL_NAMES[hh % SCHOOL_NAMES.size()]
        elif m < 30:
            kind = "venue"
            sub = "football" if hh % 2 == 0 else "basket"
            nm = "מגרש כדורגל" if sub == "football" else "מגרש כדורסל"
        elif m < 32:
            kind = "venue"
            sub = "construction"
            nm = "אתר בנייה"
        elif m < 36:
            kind = "venue"
            sub = "parking"
            nm = "חניון העיר"
        elif m < 40:
            kind = "venue"
            sub = "office"
            nm = OFFICE_NAMES[hh % OFFICE_NAMES.size()]
        elif m < 42:
            kind = "venue"
            sub = "clinic"
            nm = CLINIC_NAMES[hh % CLINIC_NAMES.size()]
    var p := {
        "kind": kind, "name": nm if nm != "" else addr, "sub": sub, "i": i, "j": j, "h": h,
        "door": Vector3(i * S + S * 0.5, 0.0, (j + 1) * S - R * 0.5 - SET * 0.5),
        "node": Vector2i(i, j + 1), "addr": addr,
    }
    _poi_cache[key] = p
    return p


func random_poi(kind: String, near: Vector3, radius: float) -> Dictionary:
    for _t in range(300):
        var p := poi(randi() % N, randi() % N)
        if p.kind == kind and p.door.distance_to(near) <= radius and p.door.distance_to(near) > 40.0:
            return p
    for i in range(N):
        for j in range(N):
            var p := poi(i, j)
            if p.kind == kind:
                return p
    return poi(0, 0)


func nearest_poi(kind: String, pos: Vector3, sub := "") -> Dictionary:
    var best := {}
    var bd := 1e12
    for i in range(N):
        for j in range(N):
            var p := poi(i, j)
            if p.kind == kind and (sub == "" or p.sub == sub):
                var d: float = p.door.distance_to(pos)
                if d < bd:
                    bd = d
                    best = p
    return best


func destinations(pos: Vector3) -> Array:
    var out: Array = []
    for k in LAND:
        out.append(poi(k.x, k.y))
    out.append(poi(RAIL_COL, STATION_ROW))
    for spec in [["restaurant", ""], ["bank", ""], ["supermarket", ""], ["venue", "park"], ["venue", "gas"], ["venue", "clinic"]]:
        var r := nearest_poi(spec[0], pos, spec[1])
        if not r.is_empty():
            out.append(r)
    return out


func street_name_h(row: int) -> String:
    return H_NAMES.get(row, "רחוב %d" % row)


func street_name_v(col: int) -> String:
    return V_NAMES.get(col, "רחוב %d" % (col + 30))


func street_name(a: Vector3, b: Vector3) -> String:
    if absf(b.x - a.x) > absf(b.z - a.z):
        return street_name_h(roundi(a.z / S))
    return street_name_v(roundi(a.x / S))


func route(from: Vector3, p: Dictionary) -> PackedVector3Array:
    var a := _nid(clampi(roundi(from.x / S), 0, N), clampi(roundi(from.z / S), 0, N))
    var b := _nid(p.node.x, p.node.y)
    var out := PackedVector3Array()
    for id in astar.get_id_path(a, b):
        out.append(Vector3((id % (N + 1)) * S, 0.0, floori(float(id) / (N + 1)) * S))
    out.append(p.door)
    return out


func lamp_points(bi: int, bj: int) -> Array:
    var x0 := bi * S + R * 0.5
    var z0 := bj * S + R * 0.5
    var w := S - R
    return [Vector3(x0 + 1.5, 0, z0 + 1.5), Vector3(x0 + w - 1.5, 0, z0 + w - 1.5)]


func nearest_lamps(pos: Vector3, n: int) -> Array:
    var arr: Array = []
    var bi := floori(pos.x / S)
    var bj := floori(pos.z / S)
    for i in range(bi - 2, bi + 3):
        for j in range(bj - 2, bj + 3):
            if i >= 0 and j >= 0 and i < N and j < N:
                for lp in lamp_points(i, j):
                    arr.append(lp)
    arr.sort_custom(func(a, b): return a.distance_squared_to(pos) < b.distance_squared_to(pos))
    return arr.slice(0, n)


# ---------- טעינה הדרגתית ----------
func _cc(pos: Vector3) -> Vector2i:
    return Vector2i(floori(pos.x / (CHUNK * S)), floori(pos.z / (CHUNK * S)))


func _valid(c: Vector2i) -> bool:
    return c.x >= 0 and c.y >= 0 and c.x < N / CHUNK and c.y < N / CHUNK


func _wanted(pos: Vector3, vel: Vector3) -> Array:
    var c := _cc(pos)
    var out: Array = []
    for dx in range(-load_r, load_r + 1):
        for dz in range(-load_r, load_r + 1):
            var w := c + Vector2i(dx, dz)
            if _valid(w) and not out.has(w):
                out.append(w)
    if vel.length() > 1.0:
        var dir := vel.normalized()
        for k in range(1, 4):
            var w := _cc(pos + dir * k * CHUNK * S * 0.9)
            if _valid(w) and not out.has(w):
                out.append(w)
    out.sort_custom(func(a, b): return (a - c).length_squared() < (b - c).length_squared())
    return out


func update_streaming(pos: Vector3, vel: Vector3) -> void:
    var c := _cc(pos)
    for w in _wanted(pos, vel):
        if not chunks.has(w) and not _queue.has(w):
            _queue.append(w)
    for k in chunks.keys():
        if absi(k.x - c.x) > load_r + 1 or absi(k.y - c.y) > load_r + 1:
            chunks[k].queue_free()
            chunks.erase(k)
    _queue = _queue.filter(func(q): return absi(q.x - c.x) <= load_r + 2 and absi(q.y - c.y) <= load_r + 2)


func _process(delta: float) -> void:
    _sig_t += delta
    _update_signals()
    if not _queue.is_empty():
        var k: Vector2i = _queue.pop_front()
        _ensure(k)


func _ensure(c: Vector2i) -> void:
    if chunks.has(c) or not _valid(c):
        return
    var root := Node3D.new()
    root.name = "C_%d_%d" % [c.x, c.y]
    var ctx := {"root": root, "body": StaticBody3D.new(), "b": {}}
    root.add_child(ctx.body)
    for bi in range(c.x * CHUNK, (c.x + 1) * CHUNK):
        for bj in range(c.y * CHUNK, (c.y + 1) * CHUNK):
            _build_block(ctx, bi, bj)
    _flush(ctx)
    add_child(root)
    chunks[c] = root


func preload_around(pos: Vector3, cb: Callable) -> void:
    var need := _wanted(pos, Vector3.ZERO)
    var total := maxi(1, need.size())
    var k := 0
    for c in need:
        _ensure(c)
        k += 1
        cb.call(float(k) / total)
        await get_tree().process_frame


func set_quality(q: int) -> void:
    load_r = [1, 2, 3][clampi(q, 0, 2)]


# ---------- כלי בנייה ----------
func _m(c: Color) -> StandardMaterial3D:
    var k := c.to_html()
    if _mats.has(k):
        return _mats[k]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.9
    _mats[k] = m
    return m


func _box(parent: Node, pos: Vector3, size: Vector3, col: Color, solid := true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _m(col)
    mi.position = pos
    parent.add_child(mi)
    if solid:
        var sb := StaticBody3D.new()
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = size
        cs.shape = sh
        sb.add_child(cs)
        mi.add_child(sb)
    return mi


func _mesh_solid(parent: Node, mesh: Mesh, pos: Vector3, col: Color, bsize: Vector3) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = _m(col)
    mi.position = pos
    parent.add_child(mi)
    var sb := StaticBody3D.new()
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = bsize
    cs.shape = sh
    sb.add_child(cs)
    mi.add_child(sb)


func _wall(pos: Vector3, size: Vector3) -> void:
    var sb := StaticBody3D.new()
    sb.position = pos
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    sb.add_child(cs)
    add_child(sb)


func _label(parent: Node, text: String, pos: Vector3, px: int, col: Color) -> void:
    var l := Label3D.new()
    l.text = text
    l.font = Game.font
    l.font_size = px
    l.pixel_size = 0.01
    l.modulate = col
    l.outline_size = 6
    l.outline_modulate = Color(0, 0, 0, 0.55)
    l.position = pos
    l.visibility_range_end = 180.0
    parent.add_child(l)


func _dec(ctx: Dictionary, key: String, pos: Vector3, size: Vector3, col := Color.WHITE, ry := 0.0, rx := 0.0) -> void:
    var b: Dictionary = ctx.b
    if not b.has(key):
        b[key] = {"xf": [], "col": []}
    var bas := Basis(Vector3.UP, ry) * Basis(Vector3.RIGHT, rx) * Basis.from_scale(size)
    b[key].xf.append(Transform3D(bas, pos))
    b[key].col.append(col)


func _solid(ctx: Dictionary, pos: Vector3, size: Vector3) -> void:
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    cs.position = pos
    ctx.body.add_child(cs)


func _mesh_for(key: String) -> Mesh:
    if _meshes.has(key):
        return _meshes[key]
    var m: Mesh
    if key == "sph":
        var s := SphereMesh.new()
        s.radius = 0.5
        s.height = 1.0
        s.radial_segments = 10
        s.rings = 5
        m = s
    elif key == "cyl":
        var c := CylinderMesh.new()
        c.top_radius = 0.5
        c.bottom_radius = 0.5
        c.height = 1.0
        c.radial_segments = 8
        m = c
    else:
        var b := BoxMesh.new()
        b.size = Vector3.ONE
        m = b
    _meshes[key] = m
    return m


func _flush(ctx: Dictionary) -> void:
    var b: Dictionary = ctx.b
    for key in b:
        var d: Dictionary = b[key]
        var n: int = d.xf.size()
        if n == 0:
            continue
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        var vc: bool = key in ["box", "sph", "cyl"]
        mm.use_colors = vc
        mm.mesh = _mesh_for(key)
        mm.instance_count = n
        for i in range(n):
            mm.set_instance_transform(i, d.xf[i])
            if vc:
                mm.set_instance_color(i, d.col[i])
        var mi := MultiMeshInstance3D.new()
        mi.multimesh = mm
        match key:
            "lamp":
                mi.material_override = _lamp_mat
            "glow":
                mi.material_override = _glow_mat
            "signs":
                mi.material_override = _sig_ns
            "sigew":
                mi.material_override = _sig_ew
            _:
                mi.material_override = _vc_mat
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        mi.visibility_range_end = 420.0
        ctx.root.add_child(mi)


func _build_ground() -> void:
    _box(self, Vector3(SIZE * 0.5 - 15.0, -0.5, SIZE * 0.5), Vector3(SIZE + 150.0, 1.0, SIZE + 120.0), Color("34373c"))
    _box(self, Vector3(-48.5, 0.02, SIZE * 0.5), Vector3(83.0, 0.04, SIZE + 120.0), Color("e3cf9f"), false)
    _box(self, Vector3(-345.0, -0.3, SIZE * 0.5), Vector3(510.0, 0.2, SIZE + 400.0), Color("2a7fb8"), false)
    _wall(Vector3(-90.0, 10, SIZE * 0.5), Vector3(2, 20, SIZE + 120))
    _wall(Vector3(SIZE + 60.0, 10, SIZE * 0.5), Vector3(2, 20, SIZE + 120))
    _wall(Vector3(SIZE * 0.5, 10, -60.0), Vector3(SIZE + 150, 20, 2))
    _wall(Vector3(SIZE * 0.5, 10, SIZE + 60.0), Vector3(SIZE + 150, 20, 2))


# ---------- בניית בלוק ----------
func _tree_at(ctx: Dictionary, pos: Vector3, rng: RandomNumberGenerator) -> void:
    var green := Color("3f7d3a").lerp(Color("6aa84a"), rng.randf())
    var t := rng.randi() % 3
    if t == 0:
        _dec(ctx, "cyl", pos + Vector3(0, 1.3, 0), Vector3(0.35, 2.6, 0.35), Color("5b4636"))
        _dec(ctx, "sph", pos + Vector3(0, 3.8, 0), Vector3(3.4, 3.0, 3.4), green)
    elif t == 1:
        _dec(ctx, "cyl", pos + Vector3(0, 3.5, 0), Vector3(0.3, 7.0, 0.3), Color("8a6f4d"))
        for k in range(6):
            _dec(ctx, "box", pos + Vector3(0, 7.0, 0), Vector3(0.3, 0.1, 3.2), green, k * PI / 3.0, 0.45)
    else:
        _dec(ctx, "sph", pos + Vector3(0, 0.7, 0), Vector3(1.8, 1.4, 1.8), green)
    _solid(ctx, pos + Vector3(0, 1.2, 0), Vector3(0.5, 2.4, 0.5))


func _car_at(ctx: Dictionary, pos: Vector3, ry: float, rng: RandomNumberGenerator) -> void:
    var col: Color = CAR_COLS[rng.randi() % CAR_COLS.size()]
    _dec(ctx, "box", pos + Vector3(0, 0.55, 0), Vector3(1.9, 0.7, 4.3), col, ry)
    _dec(ctx, "box", pos + Vector3(0, 1.15, 0).rotated(Vector3.UP, ry) + Vector3(0, 0, 0), Vector3(1.7, 0.6, 2.3), col.darkened(0.15), ry)
    _solid(ctx, pos + Vector3(0, 0.7, 0), Vector3(2.0, 1.4, 4.4) if absf(sin(ry)) < 0.5 else Vector3(4.4, 1.4, 2.0))


func _street_props(ctx: Dictionary, bi: int, bj: int, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var nx := bi * S
    var nz := bj * S
    # קווי אמצע
    _dec(ctx, "box", Vector3(g.cx, 0.02, (bj + 1) * S), Vector3(g.w - 6.0, 0.02, 0.25), Color("e8e8e8"))
    _dec(ctx, "box", Vector3((bi + 1) * S, 0.02, g.cz), Vector3(0.25, 0.02, g.w - 6.0), Color("e8e8e8"))
    # מעברי חצייה + רמזור בצומת (NW)
    for k in range(6):
        var o := -5.5 + k * 2.2
        _dec(ctx, "box", Vector3(nx + 10.5, 0.025, nz + o), Vector3(3.0, 0.02, 0.6), Color("f2f2f2"))
        _dec(ctx, "box", Vector3(nx - 10.5, 0.025, nz + o), Vector3(3.0, 0.02, 0.6), Color("f2f2f2"))
        _dec(ctx, "box", Vector3(nx + o, 0.025, nz + 10.5), Vector3(0.6, 0.02, 3.0), Color("f2f2f2"))
        _dec(ctx, "box", Vector3(nx + o, 0.025, nz - 10.5), Vector3(0.6, 0.02, 3.0), Color("f2f2f2"))
    _dec(ctx, "cyl", Vector3(nx + 8.5, 2.6, nz + 8.5), Vector3(0.18, 5.2, 0.18), Color("3a3a3a"))
    _dec(ctx, "signs", Vector3(nx + 8.5, 5.3, nz + 8.0), Vector3(0.5, 1.0, 0.4))
    _dec(ctx, "sigew", Vector3(nx + 8.0, 5.3, nz + 8.5), Vector3(0.4, 1.0, 0.5))
    _solid(ctx, Vector3(nx + 8.5, 2.0, nz + 8.5), Vector3(0.4, 4.0, 0.4))
    # עמודי תאורה
    for lp in lamp_points(bi, bj):
        _dec(ctx, "cyl", lp + Vector3(0, 2.7, 0), Vector3(0.14, 5.4, 0.14), Color("45484d"))
        _dec(ctx, "lamp", lp + Vector3(0, 5.45, 0), Vector3(0.9, 0.16, 0.4))
        _solid(ctx, lp + Vector3(0, 2.0, 0), Vector3(0.3, 4.0, 0.3))
    # עצים
    _tree_at(ctx, Vector3(g.x0 + 8.0 + rng.randf_range(-1, 1), 0, g.zf + 2.6), rng)
    _tree_at(ctx, Vector3(g.x0 + g.w - 8.0 + rng.randf_range(-1, 1), 0, g.zf + 2.6), rng)
    # תחנת אוטובוס
    if g.h % 5 == 0:
        var bx: float = g.cx + 13.0
        var bz: float = g.zf + 2.4
        _dec(ctx, "box", Vector3(bx, 2.5, bz), Vector3(3.2, 0.12, 1.6), Color("3b4a5a"))
        _dec(ctx, "box", Vector3(bx, 1.3, bz + 0.7), Vector3(3.2, 2.2, 0.08), Color("8fb4c8"))
        _dec(ctx, "box", Vector3(bx, 0.45, bz + 0.35), Vector3(2.4, 0.1, 0.5), Color("6b4f2a"))
        _dec(ctx, "box", Vector3(bx + 2.2, 3.0, bz), Vector3(0.5, 0.5, 0.05), Color("1d6fd1"))
        _dec(ctx, "cyl", Vector3(bx + 2.2, 1.5, bz), Vector3(0.08, 3.0, 0.08), Color("555555"))
        _solid(ctx, Vector3(bx, 1.2, bz + 0.7), Vector3(3.2, 2.4, 0.3))
    # ספסל ופח
    if g.h % 3 == 0:
        _dec(ctx, "box", Vector3(g.cx - 10.0, 0.45, g.zf + 3.2), Vector3(1.8, 0.1, 0.5), Color("6b4f2a"))
        _dec(ctx, "box", Vector3(g.cx - 10.0, 0.7, g.zf + 3.45), Vector3(1.8, 0.45, 0.06), Color("6b4f2a"))
        _dec(ctx, "cyl", Vector3(g.cx - 7.5, 0.5, g.zf + 3.2), Vector3(0.45, 1.0, 0.45), Color("2f6b3a"))


func _roof_stuff(ctx: Dictionary, cx: float, cz: float, bw: float, bd: float, h: float, rng: RandomNumberGenerator) -> void:
    for k in range(rng.randi_range(1, 3)):
        var rx := cx + rng.randf_range(-bw * 0.35, bw * 0.35)
        var rz := cz + rng.randf_range(-bd * 0.35, bd * 0.35)
        _dec(ctx, "cyl", Vector3(rx, h + 1.1, rz), Vector3(1.3, 1.6, 1.3), Color("c8c8c8"))
        _dec(ctx, "box", Vector3(rx + 1.8, h + 0.6, rz), Vector3(1.6, 0.12, 1.0), Color("2b3b52"), 0.0, -0.5)
    if rng.randf() < 0.5:
        _dec(ctx, "box", Vector3(cx + bw * 0.25, h + 0.9, cz - bd * 0.25), Vector3(2.0, 1.5, 2.0), Color("b9b5aa"))


func _facade_details(ctx: Dictionary, cx: float, zf: float, bw: float, h: float, rng: RandomNumberGenerator) -> void:
    var floors := int(h / 3.2)
    var cols := maxi(1, int(bw / 8.0))
    for f in range(1, floors):
        for c in range(cols):
            var bx := cx - bw * 0.5 + (c + 0.5) * bw / cols + rng.randf_range(-0.6, 0.6)
            var fy := f * 3.2
            var r := rng.randf()
            if r < 0.45:
                _dec(ctx, "box", Vector3(bx, fy + 0.1, zf + 0.55), Vector3(2.6, 0.18, 1.1), Color("c9c5bc"))
                _dec(ctx, "box", Vector3(bx, fy + 0.62, zf + 1.05), Vector3(2.6, 0.9, 0.06), Color("8fb4c8"))
            elif r < 0.7:
                _dec(ctx, "box", Vector3(bx + 1.1, fy + 1.0, zf + 0.2), Vector3(0.8, 0.5, 0.4), Color("e6e6e6"))


func _entrance(ctx: Dictionary, door: Vector3, zf: float) -> void:
    _dec(ctx, "box", Vector3(door.x, 1.2, zf + 0.08), Vector3(1.8, 2.4, 0.15), Color("2b2b2b"))
    _dec(ctx, "box", Vector3(door.x, 2.7, zf + 0.7), Vector3(3.0, 0.15, 1.4), Color("55595e"))


func _shopfront(ctx: Dictionary, cx: float, zf: float, bw: float, rng: RandomNumberGenerator) -> void:
    for side in [-1.0, 1.0]:
        _dec(ctx, "glow", Vector3(cx + side * bw * 0.27, 1.5, zf + 0.09), Vector3(bw * 0.34, 2.4, 0.12))
        var ac: Color = SIGN_COLS[rng.randi() % SIGN_COLS.size()]
        _dec(ctx, "box", Vector3(cx + side * bw * 0.27, 3.15, zf + 0.7), Vector3(bw * 0.34, 0.12, 1.3), ac, 0.0, 0.25)
    var sc: Color = SIGN_COLS[rng.randi() % SIGN_COLS.size()]
    _dec(ctx, "box", Vector3(cx, 3.9, zf + 0.1), Vector3(4.4, 0.9, 0.1), sc)
    _label(ctx.root, SHOP_LABELS[rng.randi() % SHOP_LABELS.size()], Vector3(cx, 3.9, zf + 0.2), 70, Color.WHITE)


func _build_block(ctx: Dictionary, bi: int, bj: int) -> void:
    var p := poi(bi, bj)
    var rng := RandomNumberGenerator.new()
    rng.seed = p.h
    var w := S - R
    var x0 := bi * S + R * 0.5
    var z0 := bj * S + R * 0.5
    var g := {"w": w, "x0": x0, "z0": z0, "cx": x0 + w * 0.5, "cz": z0 + w * 0.5, "zf": z0 + w - SET, "h": p.h, "inner": w - 2.0 * SET}
    _box(ctx.root, Vector3(g.cx, 0.025, g.cz), Vector3(w, 0.05, w), Color("c9c6bf"), false)
    _street_props(ctx, bi, bj, g, rng)
    match p.kind:
        "landmark":
            _build_landmark(ctx, p, g)
        "rail":
            _b_rail(ctx, p, g)
        "venue":
            match p.sub:
                "park", "waterpark":
                    _b_park(ctx, p, g, rng)
                "school":
                    _b_school(ctx, p, g, rng)
                "gas":
                    _b_gas(ctx, p, g, rng)
                "football", "basket":
                    _b_sport(ctx, p, g, rng)
                "construction":
                    _b_construction(ctx, p, g, rng)
                "parking":
                    _b_parking(ctx, p, g, rng)
                "office":
                    _b_office(ctx, p, g, rng)
                "clinic":
                    _b_clinic(ctx, p, g, rng)
        "supermarket":
            _b_supermarket(ctx, p, g, rng)
        _:
            _b_home(ctx, p, g, rng, bj)


func _b_home(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator, bj: int) -> void:
    var inner: float = g.inner
    var zf: float = g.zf
    var cx: float = g.cx
    var door: Vector3 = p.door
    var variant := rng.randi() % 7
    var col: Color = PALETTE[rng.randi() % PALETTE.size()]
    var commercial := H_NAMES.has(bj + 1)
    if p.kind != "home":
        variant = 0
    match variant:
        0, 1:
            var bw := inner * rng.randf_range(0.75, 1.0)
            var bd := inner * rng.randf_range(0.55, 0.9)
            var h := rng.randf_range(9.0, 15.0) if variant == 0 else rng.randf_range(15.0, 23.0)
            _bld(ctx, cx, zf - bd * 0.5, bw, bd, h, col)
            _roof_stuff(ctx, cx, zf - bd * 0.5, bw, bd, h, rng)
            _facade_details(ctx, cx, zf, bw, h, rng)
            if commercial or p.kind == "restaurant":
                _shopfront(ctx, cx, zf, bw, rng)
            else:
                _entrance(ctx, door, zf)
            _sign_for(ctx, p, door, zf)
        2:
            var bw := inner * rng.randf_range(0.5, 0.65)
            var bd := inner * rng.randf_range(0.5, 0.65)
            var h := rng.randf_range(26.0, 46.0)
            _bld(ctx, cx, zf - bd * 0.5 - 2.0, bw, bd, h, col.darkened(0.06))
            _bld(ctx, cx, zf - 3.0, inner * 0.9, 6.0, 4.5, col.darkened(0.15))
            _roof_stuff(ctx, cx, zf - bd * 0.5, bw, bd, h, rng)
            _entrance(ctx, door, zf)
        3:
            var bw := inner * rng.randf_range(0.8, 1.0)
            var bd := inner * rng.randf_range(0.6, 0.9)
            var h := rng.randf_range(9.0, 12.5)
            var oc: Color = OLD_PALETTE[rng.randi() % OLD_PALETTE.size()]
            _bld(ctx, cx, zf - bd * 0.5, bw, bd, h, oc)
            _facade_details(ctx, cx, zf, bw, h, rng)
            for k in range(int(h / 3.2)):
                _dec(ctx, "box", Vector3(cx, k * 3.2 + 2.4, zf + 0.06), Vector3(bw * 0.98, 0.2, 0.08), Color("8b6a4a"))
            _entrance(ctx, door, zf)
            if commercial:
                _shopfront(ctx, cx, zf, bw, rng)
        4:
            var bw := inner * 0.95
            var bd := inner * 0.8
            var h1 := rng.randf_range(8.0, 12.0)
            var h2 := rng.randf_range(8.0, 14.0)
            _bld(ctx, cx, zf - bd * 0.5, bw, bd, h1, col)
            _bld(ctx, cx + rng.randf_range(-3, 3), zf - bd * 0.5 - 3.0, bw * 0.6, bd * 0.6, h1 + h2, col.darkened(0.08))
            _facade_details(ctx, cx, zf, bw, h1, rng)
            _roof_stuff(ctx, cx, zf - bd * 0.5, bw, bd, h1 + h2, rng)
            _entrance(ctx, door, zf)
            if commercial:
                _shopfront(ctx, cx, zf, bw, rng)
        5:
            var n := rng.randi_range(2, 3)
            for k in range(n):
                var bx: float = g.x0 + SET + (k + 0.5) * inner / n
                var h := rng.randf_range(12.0, 20.0)
                var bw := inner / n - 3.0
                _bld(ctx, bx, g.z0 + SET + 14.0, bw, 18.0, h, PALETTE[rng.randi() % PALETTE.size()])
                _roof_stuff(ctx, bx, g.z0 + SET + 14.0, bw, 18.0, h, rng)
                _facade_details(ctx, bx, g.z0 + SET + 23.0, bw, h, rng)
            _dec(ctx, "box", Vector3(cx, 0.06, zf - 6.0), Vector3(inner, 0.04, 10.0), Color("5d8c47"))
            for k in range(3):
                _tree_at(ctx, Vector3(g.x0 + SET + 6.0 + k * 14.0, 0, zf - 6.0), rng)
            _entrance(ctx, door, zf)
        _:
            var bw := inner * 0.7
            var bd := inner * 0.7
            var h := rng.randf_range(18.0, 30.0)
            _bld(ctx, cx, zf - bd * 0.5, bw, bd, h, col)
            _facade_details(ctx, cx, zf, bw, h, rng)
            _roof_stuff(ctx, cx, zf - bd * 0.5, bw, bd, h, rng)
            _entrance(ctx, door, zf)
    if p.kind == "home":
        _label(ctx.root, p.addr, Vector3(door.x, 2.9, zf + 0.25), 40, Color.WHITE)


func _sign_for(ctx: Dictionary, p: Dictionary, door: Vector3, zf: float) -> void:
    if p.kind == "home":
        return
    var sc := Color("c0392b") if p.kind == "restaurant" else Color("1d4f91")
    _dec(ctx, "box", Vector3(door.x, 4.3, zf + 0.2), Vector3(7.0, 1.4, 0.14), sc)
    _label(ctx.root, p.name, Vector3(door.x, 4.3, zf + 0.32), 90, Color.WHITE)
    if p.kind == "bank":
        _dec(ctx, "box", Vector3(door.x + 3.0, 1.0, zf + 0.5), Vector3(0.7, 1.4, 0.5), Color("37474f"))


func _bld(ctx: Dictionary, cx: float, cz: float, bw: float, bd: float, h: float, col: Color) -> void:
    var nx := maxi(4, 4 * roundi(bw / 10.4))
    var ny := maxi(5, 5 * roundi(h / 16.0))
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(bw, h, bd)
    mi.mesh = bm
    mi.material_override = _fac_mat(col, nx, ny)
    mi.position = Vector3(cx, h * 0.5, cz)
    ctx.root.add_child(mi)
    _solid(ctx, mi.position, Vector3(bw, h, bd))
    _dec(ctx, "box", Vector3(cx, h + 0.15, cz), Vector3(bw + 0.4, 0.3, bd + 0.4), Color("8c8c88"))


func _b_supermarket(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var inner: float = g.inner
    var zf: float = g.zf
    var bw := inner
    var bd := 20.0
    _bld(ctx, g.cx, zf - bd * 0.5, bw, bd, 8.0, Color("f0f0ea"))
    _dec(ctx, "glow", Vector3(g.cx, 1.8, zf + 0.09), Vector3(bw * 0.8, 3.0, 0.12))
    _dec(ctx, "box", Vector3(g.cx, 3.7, zf + 1.2), Vector3(bw * 0.8, 0.2, 2.4), Color("2e8b57"))
    _dec(ctx, "box", Vector3(g.cx, 6.2, zf + 0.15), Vector3(14.0, 2.0, 0.2), Color("1f7a45"))
    _label(ctx.root, p.name, Vector3(g.cx, 6.2, zf + 0.3), 120, Color.WHITE)
    for k in range(4):
        _dec(ctx, "box", Vector3(g.cx - 12.0 + k * 1.6, 0.5, zf + 3.5), Vector3(0.7, 0.9, 1.0), Color("9aa0a6"))
    _dec(ctx, "box", Vector3(g.cx, 0.06, zf - bd - 6.0), Vector3(inner, 0.04, 10.0), Color("45484d"))
    for k in range(5):
        _car_at(ctx, Vector3(g.x0 + SET + 6.0 + k * 7.5, 0, zf - bd - 6.0), 0.0, rng)
    _roof_stuff(ctx, g.cx, zf - bd * 0.5, bw, bd, 8.0, rng)


func _b_park(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var w: float = g.w
    _dec(ctx, "box", Vector3(g.cx, 0.07, g.cz), Vector3(w - 1.0, 0.06, w - 1.0), Color("5d8c47"))
    _dec(ctx, "box", Vector3(g.cx, 0.1, g.cz), Vector3(3.0, 0.04, w - 1.0), Color("cbbf9d"))
    _dec(ctx, "box", Vector3(g.cx, 0.1, g.cz), Vector3(w - 1.0, 0.04, 3.0), Color("cbbf9d"))
    var n := 9
    for k in range(n):
        var tx: float = g.x0 + 4.0 + rng.randf() * (w - 8.0)
        var tz: float = g.z0 + 4.0 + rng.randf() * (g.zf - g.z0 - 8.0)
        if absf(tx - g.cx) > 3.0 and absf(tz - g.cz) > 3.0:
            _tree_at(ctx, Vector3(tx, 0, tz), rng)
    for k in range(3):
        _dec(ctx, "box", Vector3(g.cx + 4.0 + k * 5.0, 0.45, g.cz + 2.4), Vector3(1.8, 0.1, 0.5), Color("6b4f2a"))
    _dec(ctx, "cyl", Vector3(g.cx - 4.0, 0.5, g.cz - 2.4), Vector3(0.45, 1.0, 0.45), Color("2f6b3a"))
    if p.sub == "waterpark":
        for k in range(2):
            _dec(ctx, "box", Vector3(g.x0 + 12.0 + k * 18.0, 0.14, g.z0 + 12.0), Vector3(12.0, 0.12, 9.0), Color("39a7e0"))
        _dec(ctx, "box", Vector3(g.x0 + 40.0, 3.0, g.z0 + 10.0), Vector3(3.0, 6.0, 3.0), Color("e67e22"))
        _dec(ctx, "box", Vector3(g.x0 + 40.0, 2.7, g.z0 + 18.0), Vector3(1.6, 0.3, 11.0), Color("f1c40f"), 0.0, 0.5)
        _solid(ctx, Vector3(g.x0 + 40.0, 3.0, g.z0 + 10.0), Vector3(3.0, 6.0, 3.0))
    else:
        _dec(ctx, "box", Vector3(g.x0 + 10.0, 1.2, g.z0 + 10.0), Vector3(0.2, 2.4, 3.0), Color("d62828"))
        _dec(ctx, "box", Vector3(g.x0 + 10.0, 1.2, g.z0 + 14.0), Vector3(4.0, 0.15, 0.15), Color("1d6fd1"), 0.0, 0.0)
    _label(ctx.root, p.name, Vector3(g.cx, 3.0, g.zf + 0.5), 100, Color("ffffff"))


func _b_school(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var zf: float = g.zf
    _bld(ctx, g.cx, g.z0 + SET + 8.0, g.inner, 14.0, 11.0, Color("efe3c2"))
    _bld(ctx, g.x0 + SET + 6.0, g.z0 + SET + 24.0, 12.0, 20.0, 11.0, Color("efe3c2"))
    _dec(ctx, "box", Vector3(g.cx + 6.0, 0.07, zf - 8.0), Vector3(g.inner - 16.0, 0.05, 18.0), Color("7b8088"))
    _dec(ctx, "box", Vector3(g.cx + 6.0, 0.1, zf - 8.0), Vector3(g.inner - 18.0, 0.03, 0.2), Color("f2f2f2"))
    _dec(ctx, "box", Vector3(g.cx + 6.0, 0.1, zf - 8.0), Vector3(0.2, 0.03, 16.0), Color("f2f2f2"))
    for k in range(10):
        if absf(g.x0 + SET + k * 4.2 - g.cx) > 3.0:
            _dec(ctx, "box", Vector3(g.x0 + SET + k * 4.2, 0.9, zf - 0.2), Vector3(0.08, 1.8, 0.08), Color("4a4f55"))
    _dec(ctx, "box", Vector3(g.cx, 6.5, g.z0 + SET + 1.4), Vector3(9.0, 1.6, 0.15), Color("c0392b"))
    _label(ctx.root, p.name, Vector3(g.cx, 6.5, g.z0 + SET + 1.6), 90, Color.WHITE)
    _entrance(ctx, p.door, zf)


func _b_gas(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var cz: float = g.zf - 14.0
    _dec(ctx, "box", Vector3(g.cx, 0.06, g.zf - 12.0), Vector3(g.inner, 0.04, 24.0), Color("4a4d52"))
    _dec(ctx, "box", Vector3(g.cx, 5.2, cz), Vector3(18.0, 0.7, 10.0), Color("e8e8e8"))
    _dec(ctx, "lamp", Vector3(g.cx, 4.8, cz), Vector3(17.0, 0.1, 9.0))
    _dec(ctx, "box", Vector3(g.cx, 5.2, cz + 5.1), Vector3(18.0, 0.7, 0.2), Color("d62828"))
    for sx in [-7.0, 7.0]:
        for sz in [-3.5, 3.5]:
            _dec(ctx, "cyl", Vector3(g.cx + sx, 2.5, cz + sz), Vector3(0.5, 5.0, 0.5), Color("d0d0d0"))
            _solid(ctx, Vector3(g.cx + sx, 2.5, cz + sz), Vector3(0.6, 5.0, 0.6))
    for k in range(4):
        var pc := Color("d62828") if k % 2 == 0 else Color("1d6fd1")
        _dec(ctx, "box", Vector3(g.cx - 4.5 + k * 3.0, 0.9, cz), Vector3(0.8, 1.8, 0.6), pc)
        _solid(ctx, Vector3(g.cx - 4.5 + k * 3.0, 0.9, cz), Vector3(0.8, 1.8, 0.6))
    _bld(ctx, g.cx + 12.0, g.z0 + SET + 5.0, 12.0, 8.0, 4.5, Color("f0f0ea"))
    _dec(ctx, "cyl", Vector3(g.x0 + SET + 3.0, 4.0, g.zf - 2.0), Vector3(0.5, 8.0, 0.5), Color("555555"))
    _dec(ctx, "box", Vector3(g.x0 + SET + 3.0, 8.4, g.zf - 2.0), Vector3(3.2, 1.8, 0.3), Color("f1c40f"))
    _label(ctx.root, p.name, Vector3(g.cx, 5.2, cz + 5.35), 80, Color.WHITE)


func _b_sport(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var cz: float = g.zf - 20.0
    var field := Color("3f9a45") if p.sub == "football" else Color("c5733a")
    _dec(ctx, "box", Vector3(g.cx, 0.07, cz), Vector3(g.inner, 0.05, 36.0), field)
    var ln := Color("f4f4f4")
    _dec(ctx, "box", Vector3(g.cx, 0.1, cz), Vector3(g.inner - 2.0, 0.03, 0.2), ln)
    _dec(ctx, "box", Vector3(g.cx, 0.1, cz - 17.0), Vector3(g.inner - 2.0, 0.03, 0.2), ln)
    _dec(ctx, "box", Vector3(g.cx, 0.1, cz + 17.0), Vector3(g.inner - 2.0, 0.03, 0.2), ln)
    _dec(ctx, "box", Vector3(g.cx - g.inner * 0.5 + 1.0, 0.1, cz), Vector3(0.2, 0.03, 34.0), ln)
    _dec(ctx, "box", Vector3(g.cx + g.inner * 0.5 - 1.0, 0.1, cz), Vector3(0.2, 0.03, 34.0), ln)
    for sd in [-1.0, 1.0]:
        var gx: float = g.cx + sd * (g.inner * 0.5 - 0.6)
        if p.sub == "football":
            _dec(ctx, "box", Vector3(gx, 1.2, cz - 3.0), Vector3(0.12, 2.4, 0.12), ln)
            _dec(ctx, "box", Vector3(gx, 1.2, cz + 3.0), Vector3(0.12, 2.4, 0.12), ln)
            _dec(ctx, "box", Vector3(gx, 2.4, cz), Vector3(0.12, 0.12, 6.2), ln)
        else:
            _dec(ctx, "cyl", Vector3(gx, 1.7, cz), Vector3(0.12, 3.4, 0.12), Color("555555"))
            _dec(ctx, "box", Vector3(gx - sd * 0.3, 3.2, cz), Vector3(0.1, 1.0, 1.6), Color("f4f4f4"))
    for k in range(10):
        if absf(g.x0 + SET + k * 4.2 - g.cx) > 3.0:
            _dec(ctx, "box", Vector3(g.x0 + SET + k * 4.2, 0.7, g.zf - 0.2), Vector3(0.06, 1.4, 0.06), Color("4a4f55"))
    _label(ctx.root, p.name, Vector3(g.cx, 3.0, g.zf + 0.5), 90, Color.WHITE)


func _b_construction(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    _dec(ctx, "box", Vector3(g.cx, 0.07, g.cz), Vector3(g.w - 1.0, 0.05, g.w - 1.0), Color("8a6b4a"))
    for k in range(3):
        _dec(ctx, "box", Vector3(g.cx, 3.0 + k * 3.4, g.cz - 6.0), Vector3(20.0, 0.4, 16.0), Color("aaa9a3"))
        for sx in [-9.0, 0.0, 9.0]:
            for sz in [-6.0, 6.0]:
                _dec(ctx, "box", Vector3(g.cx + sx, 1.5 + k * 3.4, g.cz - 6.0 + sz), Vector3(0.5, 3.0, 0.5), Color("9c9b95"))
    _solid(ctx, Vector3(g.cx, 6.0, g.cz - 6.0), Vector3(20.0, 12.0, 16.0))
    _dec(ctx, "box", Vector3(g.x0 + SET + 4.0, 20.0, g.z0 + SET + 4.0), Vector3(1.2, 40.0, 1.2), Color("e5a50a"))
    _dec(ctx, "box", Vector3(g.x0 + SET + 14.0, 40.0, g.z0 + SET + 4.0), Vector3(30.0, 1.0, 1.0), Color("e5a50a"))
    _dec(ctx, "box", Vector3(g.x0 + SET - 2.0, 40.0, g.z0 + SET + 4.0), Vector3(6.0, 1.6, 1.6), Color("555555"))
    _solid(ctx, Vector3(g.x0 + SET + 4.0, 20.0, g.z0 + SET + 4.0), Vector3(1.4, 40.0, 1.4))
    for k in range(4):
        _dec(ctx, "box", Vector3(g.x0 + SET + 8.0 + k * 6.0, 0.8, g.zf - 8.0), Vector3(4.0, 1.6, 2.4), CAR_COLS[k + 1])
        _solid(ctx, Vector3(g.x0 + SET + 8.0 + k * 6.0, 0.8, g.zf - 8.0), Vector3(4.0, 1.6, 2.4))
    for k in range(11):
        if absf(g.x0 + 1.5 + k * 4.4 - g.cx) > 3.0:
            _dec(ctx, "box", Vector3(g.x0 + 1.5 + k * 4.4, 1.0, g.zf), Vector3(4.2, 2.0, 0.08), Color("2f7a3a"))
            _solid(ctx, Vector3(g.x0 + 1.5 + k * 4.4, 1.0, g.zf), Vector3(4.2, 2.0, 0.2))
    _label(ctx.root, p.name, Vector3(g.cx, 3.0, g.zf + 0.5), 90, Color("ffcc00"))


func _b_parking(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    _dec(ctx, "box", Vector3(g.cx, 0.06, g.cz), Vector3(g.w - 2.0, 0.04, g.w - 2.0), Color("3d4046"))
    for row in range(2):
        var rz: float = g.z0 + 10.0 + row * 20.0
        for k in range(9):
            var sx: float = g.x0 + 5.0 + k * 4.8
            _dec(ctx, "box", Vector3(sx, 0.09, rz), Vector3(0.12, 0.02, 5.0), Color("e8e8e8"))
            if rng.randf() < 0.65:
                _car_at(ctx, Vector3(sx + 2.4, 0, rz), 0.0, rng)
    _dec(ctx, "box", Vector3(g.cx - 4.0, 0.9, g.zf - 1.0), Vector3(6.0, 0.15, 0.15), Color("d62828"))
    _dec(ctx, "box", Vector3(g.cx + 5.0, 1.5, g.zf - 1.0), Vector3(0.6, 3.0, 0.6), Color("555555"))
    _label(ctx.root, p.name, Vector3(g.cx, 3.2, g.zf + 0.5), 100, Color("1d6fd1"))


func _b_office(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    var gl: Color = GLASS[rng.randi() % GLASS.size()]
    var h := rng.randf_range(42.0, 72.0)
    _bld(ctx, g.cx, g.zf - 20.0, g.inner * 0.95, 34.0, 6.0, Color("d9dde0"))
    _bld(ctx, g.cx, g.zf - 22.0, 22.0, 22.0, h, gl)
    _dec(ctx, "box", Vector3(g.cx, h + 1.5, g.zf - 22.0), Vector3(8.0, 3.0, 8.0), Color("9aa0a6"))
    _dec(ctx, "box", Vector3(g.cx, 3.0, g.zf + 0.2), Vector3(g.inner * 0.6, 3.5, 0.15), Color("1d3b5a"))
    _entrance(ctx, p.door, g.zf)
    _label(ctx.root, p.name, Vector3(g.cx, 5.3, g.zf + 0.35), 90, Color.WHITE)


func _b_clinic(ctx: Dictionary, p: Dictionary, g: Dictionary, rng: RandomNumberGenerator) -> void:
    _bld(ctx, g.cx, g.zf - 9.0, g.inner * 0.8, 18.0, 9.0, Color("f4f6f6"))
    _dec(ctx, "box", Vector3(g.cx, 6.5, g.zf + 0.12), Vector3(3.0, 0.8, 0.12), Color("d62828"))
    _dec(ctx, "box", Vector3(g.cx, 6.5, g.zf + 0.12), Vector3(0.8, 3.0, 0.12), Color("d62828"))
    _entrance(ctx, p.door, g.zf)
    _label(ctx.root, p.name, Vector3(g.cx, 4.2, g.zf + 0.3), 80, Color("1d6fd1"))


func _b_rail(ctx: Dictionary, p: Dictionary, g: Dictionary) -> void:
    _dec(ctx, "box", Vector3(g.cx, 0.06, g.cz), Vector3(g.w - 1.0, 0.05, g.w - 1.0), Color("7b766d"))
    _dec(ctx, "box", Vector3(g.cx, 5.5, g.cz), Vector3(7.0, 1.0, S), Color("8f918f"))
    for off in [-0.72, 0.72]:
        _dec(ctx, "box", Vector3(g.cx + off, 6.1, g.cz), Vector3(0.1, 0.12, S), Color("b0b4b8"))
    for k in range(int(S / 2.0)):
        _dec(ctx, "box", Vector3(g.cx, 6.0, g.cz - S * 0.5 + 1.0 + k * 2.0), Vector3(2.4, 0.1, 0.4), Color("5b4636"))
    _dec(ctx, "box", Vector3(g.cx, 2.5, g.cz), Vector3(2.2, 5.0, 2.2), Color("a8a8a2"))
    _solid(ctx, Vector3(g.cx, 2.5, g.cz), Vector3(2.2, 5.0, 2.2))
    if p.sub == "station":
        _dec(ctx, "box", Vector3(g.cx + 6.0, 5.9, g.cz), Vector3(5.0, 0.5, S), Color("c9c9c4"))
        _dec(ctx, "box", Vector3(g.cx + 3.0, 10.0, g.cz), Vector3(14.0, 0.4, 40.0), Color("dfe3e6"))
        for sz in [-14.0, 0.0, 14.0]:
            _dec(ctx, "cyl", Vector3(g.cx + 8.0, 7.9, g.cz + sz), Vector3(0.3, 4.0, 0.3), Color("55595e"))
        _dec(ctx, "box", Vector3(g.cx, 3.0, g.zf + 0.2), Vector3(12.0, 4.0, 0.2), Color("1d4f91"))
        _label(ctx.root, "תחנת רכבת תל אביב", Vector3(g.cx, 3.0, g.zf + 0.4), 90, Color.WHITE)


func _build_landmark(ctx: Dictionary, p: Dictionary, g: Dictionary) -> void:
    var root: Node3D = ctx.root
    var cx: float = g.cx
    var cz: float = g.cz
    var zf: float = g.zf
    var door: Vector3 = p.door
    var sub: String = p.sub
    var sign_y := 6.0
    match sub:
        "azrieli":
            var cy := CylinderMesh.new()
            cy.top_radius = 6.0
            cy.bottom_radius = 6.0
            cy.height = 110.0
            cy.radial_segments = 24
            _mesh_solid(root, cy, Vector3(cx - 14.0, 55.0, cz), Color("9fb3c4"), Vector3(12, 110, 12))
            var tr := CylinderMesh.new()
            tr.top_radius = 7.0
            tr.bottom_radius = 7.0
            tr.height = 110.0
            tr.radial_segments = 3
            _mesh_solid(root, tr, Vector3(cx, 55.0, cz), Color("8da4b8"), Vector3(12, 110, 11))
            _box(root, Vector3(cx + 14.0, 55.0, cz), Vector3(11, 110, 11), Color("a9bccb"))
        "mall":
            _bld(ctx, cx, cz, 38.0, 30.0, 16.0, Color("c9d1d6"))
            _dec(ctx, "glow", Vector3(cx, 2.0, zf - 14.0), Vector3(30.0, 3.4, 0.2))
            sign_y = 10.0
        "market":
            for a in range(3):
                for b in range(5):
                    _box(root, Vector3(cx - 16.0 + b * 8.0, 1.2, cz - 8.0 + a * 8.0), Vector3(4, 2.4, 3), SIGN_COLS[(a + b) % SIGN_COLS.size()])
        "beach":
            _box(root, Vector3(cx, 1.75, cz), Vector3(7, 3.5, 5), Color("f2efe6"))
            _box(root, Vector3(cx + 12.0, 2.0, cz), Vector3(2, 4, 2), Color("d62828"))
            _box(root, Vector3(cx + 12.0, 4.5, cz), Vector3(3, 1.6, 3), Color("f2c200"))
        "plaza":
            var fc := CylinderMesh.new()
            fc.top_radius = 3.0
            fc.bottom_radius = 3.0
            fc.height = 1.0
            _mesh_solid(root, fc, Vector3(cx, 0.5, cz), Color("9ec5d8"), Vector3(6, 1, 6))
            var rng := RandomNumberGenerator.new()
            rng.seed = 5
            for k in range(4):
                _tree_at(ctx, Vector3(cx - 12.0 + k * 8.0, 0, cz - 10.0), rng)
        "ayalon":
            _box(root, Vector3(cx - 12.0, 0.6, cz), Vector3(2, 1.2, g.w - 8.0), Color("8d8d8d"))
            _box(root, Vector3(cx + 12.0, 0.6, cz), Vector3(2, 1.2, g.w - 8.0), Color("8d8d8d"))
            sign_y = 4.0
    _label(root, p.name, Vector3(door.x, sign_y, zf + 0.4), 110, Color("ffd600"))
