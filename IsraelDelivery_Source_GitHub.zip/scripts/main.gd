extends Node
## התזמור: עולם, שחקן, תנועה, שעון משחק ויום/לילה, אודיו, זרימת משימות, שמירה והגדרות.

const RES := [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080), Vector2i(2560, 1440)]

var world: World
var traffic: Traffic
var player: Player
var ui: UI
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var marker: MeshInstance3D
var marker_mat: StandardMaterial3D
var customer: Figure = null
var sfx_player: AudioStreamPlayer
var eng_player: AudioStreamPlayer
var amb_city: AudioStreamPlayer
var amb_night: AudioStreamPlayer
var lamp_lights: Array = []
var sounds := {}
var eng_streams := {}
var _eng_kind := ""
var in_game := false
var is_paused := false
var _offer_t := 8.0
var _save_t := 0.0
var _pos_t := 0.0
var _lamp_t := 0.0
var _last_state := ""
var _last_night := -1.0


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    get_window().title = "משלוחים בישראל"
    world = World.new()
    world.process_mode = Node.PROCESS_MODE_PAUSABLE
    add_child(world)
    Game.world = world
    traffic = Traffic.new()
    traffic.process_mode = Node.PROCESS_MODE_PAUSABLE
    add_child(traffic)
    _make_environment()
    marker = MeshInstance3D.new()
    var cy := CylinderMesh.new()
    cy.top_radius = 1.4
    cy.bottom_radius = 1.4
    cy.height = 50.0
    marker.mesh = cy
    var mm := StandardMaterial3D.new()
    mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mm.albedo_color = Color(1, 0.84, 0, 0.3)
    marker.material_override = mm
    marker_mat = mm
    marker.visible = false
    add_child(marker)
    _make_audio()
    ui = UI.new()
    ui.main = self
    add_child(ui)
    Game.notify.connect(_on_notify)
    Game.sfx.connect(_play)
    Game.mission_changed.connect(_on_mission_changed)
    Game.appearance_changed.connect(_on_appearance)
    apply_settings()
    ui.show_main_menu()
    if OS.get_cmdline_user_args().has("--autotest"):
        _autotest.call_deferred()


# ---------- אודיו (מחולל, ללא קבצי סאונד חיצוניים) ----------
func _tone(freqs: Array, dur := 0.13) -> AudioStreamWAV:
    var rate := 22050
    var n := int(rate * dur)
    var data := PackedByteArray()
    data.resize(n * 2 * freqs.size())
    var idx := 0
    for f in freqs:
        for k in range(n):
            var e := 1.0 - float(k) / n
            data.encode_s16(idx, int(sin(TAU * f * k / rate) * e * 0.4 * 32767.0))
            idx += 2
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = data
    return w


func _loop(kind: String) -> AudioStreamWAV:
    var rate := 22050
    var n := rate
    var data := PackedByteArray()
    data.resize(n * 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 11
    var lp := 0.0
    for k in range(n):
        var t := float(k) / rate
        var v := 0.0
        match kind:
            "electric":
                v = sin(TAU * 220.0 * t) * 0.5 + sin(TAU * 440.0 * t) * 0.25 + sin(TAU * 660.0 * t) * 0.1
            "motor":
                v = (fposmod(t * 70.0, 1.0) * 2.0 - 1.0) * 0.5 + sin(TAU * 140.0 * t) * 0.3 + sin(TAU * 35.0 * t) * 0.3
            "city":
                lp = lerpf(lp, rng.randf_range(-1.0, 1.0), 0.04)
                v = lp * 1.6
            "night":
                var pulse := 1.0 if fposmod(t * 6.0, 1.0) < 0.35 else 0.0
                v = sin(TAU * 4200.0 * t) * pulse * 0.4
        data.encode_s16(k * 2, int(clampf(v, -1.0, 1.0) * 0.5 * 32767.0))
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = data
    w.loop_mode = AudioStreamWAV.LOOP_FORWARD
    w.loop_begin = 0
    w.loop_end = n
    return w


func _make_audio() -> void:
    sfx_player = AudioStreamPlayer.new()
    add_child(sfx_player)
    sounds = {
        "offer": _tone([880, 1175]), "pickup": _tone([660, 880]), "done": _tone([660, 880, 1320]),
        "error": _tone([220]), "atm": _tone([700, 900]), "buy": _tone([1000, 1300]),
        "boost": _tone([300, 500, 800], 0.1), "phone": _tone([1200], 0.06),
    }
    eng_streams = {"electric": _loop("electric"), "motor": _loop("motor")}
    eng_player = AudioStreamPlayer.new()
    eng_player.volume_db = -60.0
    add_child(eng_player)
    amb_city = AudioStreamPlayer.new()
    amb_city.stream = _loop("city")
    amb_city.volume_db = -60.0
    add_child(amb_city)
    amb_night = AudioStreamPlayer.new()
    amb_night.stream = _loop("night")
    amb_night.volume_db = -60.0
    add_child(amb_night)


func _vol_db(rel: float) -> float:
    return linear_to_db(maxf(0.0001, float(Game.settings.get("volume", 0.8)) * rel))


func _play(n: String) -> void:
    if bool(Game.settings.get("mute_notify", false)) or not sounds.has(n):
        return
    sfx_player.stream = sounds[n]
    sfx_player.volume_db = _vol_db(1.0)
    sfx_player.play()


func _update_audio() -> void:
    if player == null or not in_game:
        eng_player.stop()
        amb_city.stop()
        amb_night.stop()
        return
    var ek := "electric" if Game.vehicle in ["ebike", "scooter"] else "motor"
    if ek != _eng_kind:
        _eng_kind = ek
        eng_player.stream = eng_streams[ek]
    if not eng_player.playing:
        eng_player.play()
    var maxs: float = Game.vehicle_stats().max_ms
    var f := clampf(absf(player.speed) / maxf(1.0, maxs), 0.0, 1.0)
    if player.on_foot:
        f = 0.0
    eng_player.pitch_scale = 0.7 + f * 1.5 + (0.3 if player.boost_t > 0.0 else 0.0)
    eng_player.volume_db = _vol_db(0.04 + f * 0.22) if f > 0.02 else -60.0
    if not amb_city.playing:
        amb_city.play()
        amb_night.play()
    var dens := float(traffic.density) / 40.0
    amb_city.volume_db = _vol_db(0.03 + 0.08 * dens * (1.0 - world.night * 0.7))
    amb_night.volume_db = _vol_db(0.02 + 0.05 * world.night) if world.night > 0.2 else -60.0


# ---------- סביבה, יום ולילה ----------
func _make_environment() -> void:
    sun = DirectionalLight3D.new()
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 140.0
    add_child(sun)
    sky_mat = ProceduralSkyMaterial.new()
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_density = 0.0012
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    for i in range(6):
        var l := OmniLight3D.new()
        l.omni_range = 18.0
        l.light_color = Color("ffd9a0")
        l.light_energy = 0.0
        l.shadow_enabled = false
        l.visible = false
        add_child(l)
        lamp_lights.append(l)


func _update_daynight() -> void:
    var h := Game.hour_f()
    var t := (h - 6.0) / 12.0
    var elev := sin(t * PI) * 70.0
    var day := smoothstep(-4.0, 8.0, elev)
    var n := 1.0 - smoothstep(-2.0, 10.0, elev)
    sun.rotation_degrees = Vector3(-clampf(elev, 8.0, 80.0) if elev > 0.0 else -35.0, lerpf(-80.0, 80.0, clampf(t, 0.0, 1.0)), 0.0)
    sun.light_energy = lerpf(0.14, 1.25, day)
    sun.light_color = Color("7c93c9").lerp(Color("ffd9a8").lerp(Color.WHITE, clampf(elev / 45.0, 0.0, 1.0)), day)
    var dusk := 1.0 - clampf(absf(elev - 2.0) / 12.0, 0.0, 1.0)
    sky_mat.sky_top_color = Color("0a1128").lerp(Color("1e4a85"), day)
    var hor := Color("141c33").lerp(Color("a9c6e0"), day).lerp(Color("ff8a4c"), dusk * 0.65)
    sky_mat.sky_horizon_color = hor
    sky_mat.ground_horizon_color = hor
    sky_mat.ground_bottom_color = Color("0c1018").lerp(Color("3a3f46"), day)
    env.ambient_light_energy = lerpf(0.22, 1.0, day)
    env.fog_light_color = hor
    if absf(n - _last_night) > 0.02:
        _last_night = n
        world.set_night(n)
    if player != null:
        player.light.visible = n > 0.4
        player.light.shadow_enabled = false


func _update_lamp_lights() -> void:
    if player == null:
        return
    var pts: Array = world.nearest_lamps(player.global_position, lamp_lights.size())
    for i in range(lamp_lights.size()):
        var l: OmniLight3D = lamp_lights[i]
        if world.night > 0.3 and i < pts.size():
            l.visible = true
            l.global_position = pts[i] + Vector3(0, 5.0, 0)
            l.light_energy = 2.2 * world.night
        else:
            l.visible = false


func apply_settings() -> void:
    var s: Dictionary = Game.settings
    sun.shadow_enabled = bool(s.shadows)
    world.set_quality(int(s.quality))
    traffic.set_density_level(int(s.traffic))
    Engine.max_fps = int(s.fps)
    get_viewport().msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][clampi(int(s.quality), 0, 2)]
    apply_display()
    _update_daynight()


func apply_display() -> void:
    var s: Dictionary = Game.settings
    var screen := DisplayServer.screen_get_size()
    if screen.x <= 0 or DisplayServer.get_name() == "headless":
        return
    var win := get_window()
    var mode := int(s.display_mode)
    if mode == 1:
        win.mode = Window.MODE_EXCLUSIVE_FULLSCREEN
        return
    win.mode = Window.MODE_WINDOWED
    if mode == 2:
        win.borderless = true
        win.position = Vector2i(0, 0)
        win.size = screen
        return
    win.borderless = false
    var ri := clampi(int(s.res), 0, RES.size() - 1)
    var r: Vector2i = RES[ri]
    if r.x > screen.x or r.y > screen.y:
        for k in range(RES.size() - 1, -1, -1):
            if RES[k].x <= screen.x and RES[k].y <= screen.y:
                ri = k
                break
        s.res = ri
        r = RES[ri]
        Game.notify.emit("הרזולוציה שנבחרה אינה נתמכת. הוחזרה הגדרה תקינה")
    win.size = r
    win.position = (screen - r) / 2


func _on_notify(t: String) -> void:
    if bool(Game.settings.get("voice", false)):
        var voices := DisplayServer.tts_get_voices_for_language("he")
        if voices.size() > 0:
            DisplayServer.tts_speak(t, voices[0])


# ---------- זרימה ----------
func new_game() -> void:
    Game.reset_new()
    ui.show_setup()


func continue_game() -> void:
    Game.load_game()
    begin_play(false)


func begin_play(is_new: bool) -> void:
    ui.show_loading()
    Game.world = world
    var pos: Vector3 = Vector3(8 * World.S, 0.3, 12 * World.S) if is_new else Game.last_pos
    if is_new:
        Game.last_pos = pos
        Game.last_heading = 0.0
        Game.mission = {}
        Game.stop_nav()
    await world.preload_around(pos, ui.set_progress)
    if player != null:
        player.queue_free()
    player = Player.new()
    add_child(player)
    player.global_position = pos
    player.heading = Game.last_heading
    player.rotation.y = player.heading
    player.setup(Game.look, Game.company, Game.vehicle)
    Game.player = player
    traffic.setup(world, player)
    in_game = true
    is_paused = false
    get_tree().paused = false
    ui.clear_screen()
    ui.show_hud(player, world)
    _offer_t = 6.0
    _last_state = ""
    _on_mission_changed()
    apply_settings()
    _update_mouse()
    if is_new:
        Game.notify.emit("ברוך הבא, %s! הזמנה ראשונה תגיע בקרוב. P פותח את הטלפון" % Game.player_name)
        Game.save_game()


func _on_appearance() -> void:
    if player != null and in_game:
        player.setup(Game.look, Game.company, Game.vehicle)
        player.set_carrying(Game.mission.get("state", "") == "to_customer")


func _on_mission_changed() -> void:
    if player == null:
        return
    var m: Dictionary = Game.mission
    var st: String = m.get("state", "")
    marker.visible = false
    if st == "to_pickup" or st == "to_customer":
        var p: Dictionary = world.poi(m.ri, m.rj) if st == "to_pickup" else world.poi(m.hi, m.hj)
        marker.global_position = Vector3(p.door.x, 25.0, p.door.z)
        marker_mat.albedo_color = Color(1, 0.84, 0, 0.3) if st == "to_pickup" else Color(0.18, 0.8, 0.44, 0.3)
        marker.visible = true
    if st != _last_state:
        if st == "to_customer" and not bool(m.get("leave", false)):
            _spawn_customer(world.poi(m.hi, m.hj))
        elif st != "to_customer":
            _free_customer()
        _last_state = st
    player.set_carrying(st == "to_customer" and not player.bag.visible)
    # ביטול ניווט רק אם הוא היה ניווט משלוח. ניווט חופשי נשמר.
    if m.is_empty() and Game.nav_source == "mission":
        Game.stop_nav()


func _spawn_customer(p: Dictionary) -> void:
    _free_customer()
    customer = Figure.new()
    add_child(customer)
    var lk := {"skin": p.h % 5, "hair_color": (p.h / 5) % 5, "hair_style": (p.h / 25) % 4, "body": (p.h / 7) % 3, "shirt": (p.h / 11) % 6, "shorts": (p.h % 2) == 0}
    customer.build(lk, "customer")
    customer.global_position = p.door + Vector3(1.4, 0, -0.9)
    customer.rotation.y = PI


func _free_customer() -> void:
    if customer != null and is_instance_valid(customer):
        customer.queue_free()
    customer = null


func _refresh_input() -> void:
    if player != null:
        player.input_enabled = not (ui.phone_open or ui.shop_open or is_paused)
        player.phone_open = ui.phone_open
    _update_mouse()


func set_phone(open: bool, page := "home") -> void:
    if not in_game:
        return
    if open:
        ui.close_shop()
        ui.open_phone(page)
        _play("phone")
    else:
        ui.close_phone()
    _refresh_input()


func open_shop(poi: Dictionary) -> void:
    ui.close_phone()
    ui.show_shop(poi)
    _refresh_input()


func close_shop() -> void:
    ui.close_shop()
    _refresh_input()


func _update_mouse() -> void:
    if player != null and player.rmb_down and not (ui.phone_open or ui.shop_open or is_paused):
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    else:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func pause_game() -> void:
    if not in_game or is_paused:
        return
    _save_progress()
    is_paused = true
    get_tree().paused = true
    ui.show_pause()
    _refresh_input()


func resume() -> void:
    is_paused = false
    get_tree().paused = false
    ui.clear_screen()
    _refresh_input()


func _save_progress() -> void:
    if player != null:
        Game.last_pos = Vector3(player.global_position.x, maxf(0.3, player.global_position.y), player.global_position.z)
        Game.last_heading = player.heading
    Game.save_game()


func save_and_menu() -> void:
    _save_progress()
    get_tree().paused = false
    in_game = false
    is_paused = false
    traffic.player = null
    if player != null:
        player.queue_free()
        player = null
        Game.player = null
    _free_customer()
    marker.visible = false
    ui.close_phone()
    ui.close_shop()
    Game.load_game()
    ui.show_main_menu()
    _update_mouse()
    _update_audio()


func quit_game() -> void:
    if in_game:
        _save_progress()
    get_tree().quit()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        quit_game()


func _unhandled_input(event: InputEvent) -> void:
    if not in_game:
        return
    if event.is_action_pressed("pause"):
        if is_paused:
            resume()
        elif ui.shop_open:
            close_shop()
        elif ui.phone_open:
            set_phone(false)
        else:
            pause_game()
    elif is_paused:
        return
    elif event.is_action_pressed("phone"):
        set_phone(not ui.phone_open)
    elif event.is_action_pressed("map"):
        set_phone(true, "map")
    elif event.is_action_pressed("interact") and not ui.shop_open:
        var it := current_interaction()
        if it.has("fn"):
            it.fn.call()


func current_interaction() -> Dictionary:
    var m: Dictionary = Game.mission
    var p := player.global_position
    var st: String = m.get("state", "")
    if st == "to_pickup":
        var r: Dictionary = world.poi(m.ri, m.rj)
        if _near(p, r.door, 10.0):
            if absf(player.speed) < 3.0:
                return {"text": "E — איסוף משלוח מ%s" % r.name, "fn": _do_pickup}
            return {"text": "האט כדי לאסוף את ההזמנה"}
    elif st == "to_customer":
        var h: Dictionary = world.poi(m.hi, m.hj)
        if _near(p, h.door, 10.0):
            if absf(player.speed) < 3.0:
                return {"text": "E — השאר ליד הדלת" if bool(m.leave) else "E — מסירת המשלוח", "fn": _do_deliver}
            return {"text": "האט כדי למסור את ההזמנה"}
    var b: Dictionary = world.poi(clampi(floori(p.x / World.S), 0, World.N - 1), clampi(floori(p.z / World.S), 0, World.N - 1))
    if b.kind == "bank" and _near(p, b.door, 9.0):
        return {"text": "E — כספומט / בנק: %s" % b.name, "fn": func(): set_phone(true, "bank")}
    if b.kind == "supermarket" and _near(p, b.door, 9.0):
        return {"text": "E — כניסה ל%s" % b.name, "fn": func(): open_shop(b)}
    return {}


func _near(a: Vector3, b: Vector3, r: float) -> bool:
    return Vector2(a.x - b.x, a.z - b.z).length() < r


func _do_pickup() -> void:
    player.play_pickup()
    Game.pickup()


func _do_deliver() -> void:
    var m: Dictionary = Game.mission
    var h: Dictionary = world.poi(m.hi, m.hj)
    var leave := bool(m.leave)
    var summary := Game.complete_mission()
    if summary.is_empty():
        return
    player.drop_bag()
    if leave:
        var bm := MeshInstance3D.new()
        var b := BoxMesh.new()
        b.size = Vector3(0.3, 0.3, 0.16)
        bm.mesh = b
        var mt := StandardMaterial3D.new()
        mt.albedo_color = Color("111111")
        bm.material_override = mt
        add_child(bm)
        bm.global_position = h.door + Vector3(-1.0, 0.15, -1.2)
        get_tree().create_timer(8.0).timeout.connect(bm.queue_free)
    elif customer != null and is_instance_valid(customer):
        customer.pose_receive()
        var c := customer
        customer = null
        var tw := c.create_tween()
        tw.tween_interval(2.0)
        tw.tween_property(c, "position", c.position + Vector3(0, 0, -3.0), 1.5)
        tw.tween_callback(c.queue_free)
    ui.show_summary(summary)


func _process(delta: float) -> void:
    if customer != null and is_instance_valid(customer):
        customer.pose_stand(0.0, 0.0)
        customer.idle(delta, true, false)
    if not in_game or is_paused or player == null:
        return
    Game.advance_clock(delta)
    _update_daynight()
    world.update_streaming(player.global_position, player.velocity)
    Game.tick(delta)
    if Game.mission.is_empty():
        _offer_t -= delta
        if _offer_t <= 0.0:
            Game.new_offer()
            _offer_t = randf_range(15.0, 30.0)
    _pos_t += delta
    if _pos_t > 4.0:
        _pos_t = 0.0
        if player.is_on_floor():
            Game.last_pos = player.global_position
    _save_t += delta
    if _save_t > 45.0:
        _save_t = 0.0
        _save_progress()
    _lamp_t += delta
    if _lamp_t > 0.4:
        _lamp_t = 0.0
        _update_lamp_lights()
        _update_audio()
    _refresh_input_if_needed()
    var it := current_interaction()
    ui.set_prompt(str(it.get("text", "")))
    ui.update_hud(player, world)
    if marker.visible:
        marker.rotation.y += delta


func _refresh_input_if_needed() -> void:
    var want := not (ui.phone_open or ui.shop_open or is_paused)
    if player.input_enabled != want or player.phone_open != ui.phone_open:
        _refresh_input()
    elif player.rmb_down != (Input.mouse_mode == Input.MOUSE_MODE_CAPTURED):
        _update_mouse()


# ---------- בדיקה אוטומטית (רצה רק עם --autotest, לשימוש ב-CI) ----------
var _at_errors := 0


func _chk(cond: bool, msg: String) -> void:
    if cond:
        print("AT ok: ", msg)
    else:
        _at_errors += 1
        print("AUTOTEST FAIL: ", msg)


func _frames(n: int) -> void:
    for i in range(n):
        await get_tree().process_frame


func _autotest() -> void:
    await _frames(5)
    Game.reset_new()
    ui.show_setup()
    await _frames(3)
    ui._setup_name = "בדיקה"
    ui._finish_setup()
    var guard := 0
    while not in_game and guard < 3000:
        await get_tree().process_frame
        guard += 1
    _chk(in_game, "game started")
    if not in_game:
        _finish_autotest()
        return
    await _frames(30)
    _chk(world.chunks.size() > 0, "chunks loaded")
    for pg in ["home", "delivery", "map", "bank", "msgs", "profile", "vehicle", "history", "clock", "settings"]:
        set_phone(true, pg)
        await _frames(2)
    set_phone(false)
    open_shop(world.nearest_poi("supermarket", player.global_position))
    await _frames(3)
    _chk(ui.shop_open, "shop opens")
    close_shop()
    Game.new_offer()
    _chk(Game.mission.get("state", "") == "offered", "offer created")
    set_phone(true, "delivery")
    await _frames(2)
    set_phone(false)
    Game.accept()
    var m: Dictionary = Game.mission
    var rest: Dictionary = world.poi(m.ri, m.rj)
    var home: Dictionary = world.poi(m.hi, m.hj)
    Game.start_nav(rest, "mission")
    await _frames(5)
    _chk(Game.nav_route.size() > 1, "route computed")
    player.global_position = Vector3(rest.door.x, 0.3, rest.door.z)
    player.velocity = Vector3.ZERO
    player.speed = 0.0
    await _frames(5)
    var it := current_interaction()
    _chk(it.has("fn"), "pickup interaction available")
    if it.has("fn"):
        it.fn.call()
    await _frames(60)
    _chk(Game.mission.get("state", "") == "to_customer", "picked up")
    Game.start_nav(home, "mission")
    await _frames(5)
    player.global_position = Vector3(home.door.x, 0.3, home.door.z)
    player.velocity = Vector3.ZERO
    player.speed = 0.0
    await _frames(5)
    var before := Game.balance
    it = current_interaction()
    _chk(it.has("fn"), "deliver interaction available")
    if it.has("fn"):
        it.fn.call()
    _chk(Game.balance > before, "paid for delivery")
    var after := Game.balance
    _chk(Game.complete_mission().is_empty(), "no double completion")
    _chk(Game.balance == after, "no double payment")
    await _frames(10)
    player.global_position = Vector3(8 * World.S, 0.3, 12 * World.S)
    player.velocity = Vector3.ZERO
    player.speed = 0.0
    var start := player.global_position
    Input.action_press("forward")
    await get_tree().create_timer(2.0).timeout
    Input.action_release("forward")
    _chk(player.global_position.distance_to(start) > 1.0, "vehicle moves")
    player.first_person = true
    await _frames(5)
    player.first_person = false
    await _frames(5)
    Game._tx(5000, "test")
    for k in Game.VEHICLES:
        if not Game.owned.has(k):
            Game.buy_vehicle(k)
        Game.switch_vehicle(k)
        await _frames(5)
        _chk(player.kind == k, "vehicle built: " + k)
    for c in Game.COMPANIES:
        Game.company = c
        Game.appearance_changed.emit()
        await _frames(3)
    for u in Game.UPGRADES:
        Game.buy_upgrade(u)
    for q in range(3):
        Game.settings.quality = q
        apply_settings()
    Game.settings.quality = 1
    apply_settings()
    # --- שעון ויום/לילה ---
    var m0 := Game.game_minutes
    Game.advance_clock(60.0)
    _chk(absf(fposmod(Game.game_minutes - m0, 1440.0) - 60.0) < 0.01, "clock: 60 real seconds = 60 game minutes")
    ui.update_hud(player, world)
    _chk(ui.l_clock.text == ui.phone_clock.text and ui.l_clock.text == Game.clock_text(), "HUD clock equals phone clock")
    Game.game_minutes = 23.0 * 60.0
    _update_daynight()
    _chk(world.night > 0.8, "night at 23:00")
    Game.game_minutes = 12.0 * 60.0
    _update_daynight()
    _chk(world.night < 0.1, "day at 12:00")
    # --- בוסט ---
    player.global_position = Vector3(8 * World.S, 0.3, 12 * World.S)
    player.speed = 0.0
    Input.action_press("boost")
    await _frames(4)
    Input.action_release("boost")
    _chk(player.boost_t > 0.0 and player.boost_t <= 5.0, "boost active")
    await get_tree().create_timer(5.6).timeout
    _chk(player.boost_t == 0.0 and player.boost_cd > 0.0, "boost ended and cooldown started")
    # --- ירידה ועלייה ---
    player.speed = 0.0
    player.toggle_foot()
    await _frames(5)
    _chk(player.on_foot, "dismounted")
    player.toggle_foot()
    await _frames(5)
    _chk(not player.on_foot, "remounted")
    # --- ניווט חופשי עצמאי מהזמנות ---
    var bank_poi: Dictionary = world.nearest_poi("bank", player.global_position)
    Game.start_nav(bank_poi)
    _chk(Game.nav_active and Game.nav_route.size() > 1, "free navigation started")
    var last_pt: Vector3 = Game.nav_route[Game.nav_route.size() - 1]
    _chk(last_pt.is_equal_approx(bank_poi.door), "navigation ends at building access point")
    Game.mission = {}
    Game.new_offer()
    Game.decline()
    _chk(Game.nav_active and Game.nav_source == "free", "free nav survives declined order")
    Game.new_offer()
    Game.accept()
    Game.cancel_mission()
    _chk(Game.nav_active, "free nav survives cancelled order")
    Game.stop_nav()
    # --- כלכלה ---
    Game.cash = 100
    Game.balance = 50
    _chk(Game.deposit(30) and Game.cash == 70 and Game.balance == 80, "deposit")
    _chk(Game.withdraw(10) and Game.cash == 80 and Game.balance == 70, "withdraw")
    _chk(not Game.deposit(1000) and Game.cash == 80, "deposit over cash rejected")
    _chk(not Game.withdraw(1000) and Game.balance == 70, "withdraw over balance rejected")
    _chk(not Game.withdraw(-5) and not Game.deposit(0), "invalid amounts rejected")
    _chk(Game.buy_item("water") and Game.cash == 75, "buy water 5")
    Game.cash = 3
    _chk(not Game.buy_item("milk") and Game.cash == 3, "purchase rejected without cash")
    # --- תנועה ורכבת ---
    Game.game_minutes = 17.0 * 60.0
    await get_tree().create_timer(1.0).timeout
    var act := 0
    for c in traffic.cars:
        if c.on:
            act += 1
    _chk(traffic.cars.size() == Traffic.POOL and act > 0, "traffic pool active at rush hour")
    _chk(traffic._train != null, "train exists")
    Game.cash = 77
    Game.game_minutes = 555.0
    var bal := Game.balance
    Game.save_game()
    Game.balance = 0
    Game.cash = 0
    _chk(Game.load_game(), "save loaded")
    _chk(Game.balance == bal, "balance restored from save")
    _chk(Game.cash == 77 and absf(Game.game_minutes - 555.0) < 1.0, "cash and game time restored from save")
    player.global_position = Vector3(20 * World.S, 0.3, 4 * World.S)
    await _frames(90)
    _chk(world.chunks.size() > 0, "streaming after teleport")
    pause_game()
    await _frames(3)
    resume()
    _finish_autotest()


func _finish_autotest() -> void:
    if _at_errors == 0:
        print("AUTOTEST OK")
    else:
        print("AUTOTEST FAILED: ", _at_errors, " errors")
    get_tree().quit(1 if _at_errors > 0 else 0)
